BED Documentation

Added all base features

• Front-end for the web application (You are allowed to use open source templates
downloaded from the internet)
• Persistent login (and logout)
• Search dvds by title OR category. Max rental rate can be empty which implies no
budget. You can assume required search fields would be filled up. (General Public)
• View dvd details (including dvd info like rating,actors in one page)
(General Public)
• Add Actor(First Name and Last Name) (Only for Admins)
• Add new customer (Only for Admins)
• Ensure necessary JWT checking for access rights for relevant web api is done

Added Review available to all users who are logged in

Added Cart (no check out functionality)

Added Add dvd with image for staff

Schema added 1 new table (review) with 5 columns (name, film_id, review, rating, email) , 1 new column for customer (password), 1 new column for film (image)
updated schema available by running provided sql file (sakilaupdated)


To start website in VSC
open 2 terminal tabs
In the first tab run "cd .\Back_end\" without the quotation marks and "npm run start-dev'

In the second tab run "cd .\Front_end\" without the quotation marks and "npm run start-dev'

To access website open localhost:3001 in browser, this should open the home page(index.html)

Website contains 5 pages 
index.html(home page)
search.html(search for film by name,category and rental rate)
results.html(results page for films that match search details)
film.html(View dvd details (including dvd info like rating,actors in one page))
admin.html(admin page)
cart.html(nothing, i didn't have time to make it)


