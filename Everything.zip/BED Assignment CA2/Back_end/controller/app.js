//Cai Ruizhe, DAAA/1b/01 2214535

const jwt = require("jsonwebtoken");
const express = require("express");
const bodyParser = require("body-parser");
const actor = require("../models/actor");
const film = require("../models/film");
const customer = require("../models/customer");
const staff = require("../models/staff");
var app = express();
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
const isLoggedInMiddleware = require("../auth/verifyToken");
var cors = require("cors");
const review = require("../models/review");

app.options("*", cors());
app.use(cors());
app.use(bodyParser.json());
var urlencodedParser = bodyParser.urlencoded({ extended: false });
//npm run start-dev

//login
app.post("/user/login", function (req, res) {
  var email = req.query.email;
  var password = req.query.password;
  staff.loginUser(email, password, function (err, token, result) {
    if (!err) {
      res.statusCode = 200;
      res.setHeader("Content-Type", "application/json");
      delete result[0]["password"]; //clear the password in json data, do not send back to client
      console.log(result);
      res.json({
        success: true,
        UserData: JSON.stringify(result),
        token: token,
        status: "You are successfully logged in!",
      });
      res.send();
    } else {
      console.log(err);
      res.status(500);
      res.send(err.statusCode);
    }
  });
});

app.get("/film/categories", (req, res) => {
  film.findAllCategories((error, categories) => {
    if (error) {
      return;
    }
    return res.status(200).send(categories);
  });
});

//search film by title and category
app.get("/film_categories/films", (req, res) => {
  const category_id = parseInt(req.query.category, 10);
  const search = `%${req.query.search}%`;
  var rent = parseInt(req.query.rent, 10);
  film.film_categories(search, category_id, rent, (error, results) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    if (results.length === 0 || results == [] || results == null) {
      return res.status(204).send();
    }
    return res.status(200).send(results);
  });
});

//film get page info page info film thing
app.get("/film", (req, res) => {
  const film_id = parseInt(req.query.film_id, 10);
  if (isNaN(film_id)) {
    res.status(400).send({ "error message": "missing data" });
    return;
  }
  film.film_page(film_id, (error, results) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    console.log(results);
    return res.status(200).send(results);
  });
});

app.get("/store", (req, res) => {
  staff.store((error, results) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res.status(200).send(results);
  });
});

app.post("/customers", (req, res) => {
  const results = req.query;
  customer.create(results, (error, customers) => {
    if (error) {
      if (error === "Email already exists") {
        return res.status(409).send({ error_msg: "email already exist" });
      }
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res
      .status(201)
      .send({ customer_id: JSON.stringify(customers.insertId) });
  });
});

app.post("/actors", (req, res) => {
  const results = req.query;
  if (
    results.first_name == "" ||
    results.last_name == "" ||
    results.first_name == undefined ||
    results.last_name == undefined
  ) {
    res.status(400).send({ "error message": "missing data" });
    return;
  }
  actor.create(results, (error, actors) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res.status(201).send({ actor_id: JSON.stringify(actors.insertId) });
  });
});

app.get("/verifytoken", isLoggedInMiddleware, (req, res) => {
  if (req.role) res.status(200).send({ message: "token verified" });
  else res.status(400).send({ message: "token not verified" });
});

app.post("/review", (req, res) => {
  const results = req.query;
  review.create(results, (error, result) => {
    if (error) {
      if (error === "You have not rented this film") {
        return res
          .status(400)
          .send({ "error message": "You have not rented this film" });
      }
      if (error === "You have already reviewed this film") {
        return res
          .status(409)
          .send({ "error message": "You have already reviewed this film" });
      }
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res.status(201).send({ review_id: JSON.stringify(result.insertId) });
  });
});

app.get("/review", (req, res) => {
  const film_id = parseInt(req.query.film_id, 10);
  if (isNaN(film_id)) {
    res.status(400).send({ "error message": "missing data" });
    return;
  }
  review.review(film_id, (error, results) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res.status(200).send(results);
  });
});

app.get("/filmbyid", (req, res) => {
  const film_id = parseInt(req.query.film_id, 10);
  if (isNaN(film_id)) {
    res.status(400).send({ "error message": "missing data" });
    return;
  }
  film.filmbyid(film_id, (error, results) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res.status(200).send(results);
  });
});

app.post("/film", (req, res) => {
  const results = req.query;
  array = [];
  data = req.body.image;
  for (let key in data) {
    array[key] = data[key];
  }
  const buffer = Buffer.from(array);
  film.create(results, buffer, (error, result) => {
    if (error) {
      if (error === "Film already exists") {
        return res
          .status(409)
          .send({ "error message": "Title already exists" });
      }
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    return res.status(201).send({ film_id: JSON.stringify(result.insertId) });
  });
});

app.get("/filmimage", (req, res) => {
  const film_id = parseInt(req.query.film_id, 10);
  if (isNaN(film_id)) {
    res.status(400).send({ "error message": "missing data" });
    return;
  }
  film.filmimage(film_id, (error, results) => {
    if (error) {
      console.log(error);
      return res.status(500).send({ "error message": "internal server error" });
    }
    if(results[0].image == null){
      res.status(200).send(null);
    }
    else{
      const buffer = Buffer.from(results[0].image, "binary");
      const base64String = buffer.toString("base64");
      results = base64String;
      res.status(200).send(results);
    }
  });
});


module.exports = app;
