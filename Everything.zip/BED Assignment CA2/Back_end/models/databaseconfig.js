//Cai Ruizhe, DAAA/1b/01 2214535

const mysql = require("mysql");

const dbconnect = {
  getConnection() {
    const conn = mysql.createConnection({
      host: "localhost",
      port: 3306,
      user: "bed_dvd_root",
      password: "pa$$woRD123",
      database: "bed_dvd_db",
      dateStrings: true,
      multipleStatements: true
    });

    return conn;
  }
};

// put this at the end of the file
module.exports = dbconnect;

