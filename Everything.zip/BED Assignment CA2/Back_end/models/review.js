// Cai Ruizhe, DAAA/1b/01 2214535

const db = require("./databaseconfig");
const staff = require("./staff");
const review = {
  create: function (review, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        console.log(err);
        return callback(err, null);
      } else {
        if (review.staff == "true") {
          const createReviewQuery = `SELECT film_id from reviews WHERE email = ?;`;
          dbConn.query(createReviewQuery, [review.email], (error, email) => {
            const createReviewQuery = `SELECT customer_id from customer WHERE email = ?;`;
            dbConn.query(
              createReviewQuery,
              [review.email],
              (error, customer) => {

                let customer_ids = email.map((obj) => obj.film_id);
                if(!customer_ids.includes(review.film_id)){
                  const createReviewQuery = `SELECT i.film_id from rental r, inventory i WHERE
            r.inventory_id = i.inventory_id AND 
            r.customer_id = ?;`;
                  dbConn.query(
                    createReviewQuery,
                    [customer.id],
                    (error, results) => {

                      let filmIds = results.map((obj) => obj.film_id);
                      if (filmIds.includes(parseInt(review.film_id))) {
                        const createReviewQuery =
                          "INSERT INTO reviews (name, film_id, review, rating, email) VALUES (?, ?, ?, ?, ?);";
                        dbConn.query(
                          createReviewQuery,
                          [
                            review.name,
                            review.film_id,
                            review.review,
                            review.rating,
                            review.email,
                          ],
                          (error, results) => {
                            dbConn.end();
                            if (error) {
                              return callback(error, null);
                            }
                            return callback(null, results);
                          }
                        );
                      } else {
                        return callback("You have not rented this film", null);
                      }
                    }
                  );
                }else{
                  return callback("You have already reviewed this film", null);
                }
              }
            );
          });
        } else {
          const createReviewQuery = `SELECT film_id from reviews WHERE email = ?;`;
          dbConn.query(createReviewQuery, [review.email], (error, email) => {

            let customer_ids = email.map((obj) => obj.film_id);
            console.log(customer_ids);
            if (!customer_ids.includes(review.film_id)) {
              const createReviewQuery = `SELECT i.film_id from rental r, inventory i WHERE
            r.inventory_id = i.inventory_id AND 
            r.customer_id = ?;`;
              dbConn.query(createReviewQuery, [review.id], (error, results) => {
                let filmIds = results.map((obj) => obj.film_id);
                if (filmIds.includes(parseInt(review.film_id))) {
                  const createReviewQuery =
                    "INSERT INTO reviews (name, film_id, review, rating, email) VALUES (?, ?, ?, ?, ?);";
                  dbConn.query(
                    createReviewQuery,
                    [
                      review.name,
                      review.film_id,
                      review.review,
                      review.rating,
                      review.email,
                    ],
                    (error, results) => {
                      dbConn.end();
                      if (error) {
                        return callback(error, null);
                      }
                      return callback(null, results);
                    }
                  );
                } else {
                  return callback("You have not rented this film", null);
                }
              });
            } else {
              return callback("You have already reviewed this film", null);
            }
          });
        }
      }
    });
  },
  review: function (film_id, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        const findReviewQuery = `SELECT * FROM reviews WHERE film_id = ?;`;
        dbConn.query(findReviewQuery, [film_id], (error, results) => {
          dbConn.end();
          if (error) {
            return callback(error, null);
          }
          return callback(null, results);
        });
      }
    });
  },
};
module.exports = review;
