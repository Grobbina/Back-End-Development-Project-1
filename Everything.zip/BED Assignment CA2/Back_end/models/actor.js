// Cai Ruizhe, DAAA/1b/01 2214535

const db = require("./databaseconfig");
const actors = {
  findByID: function (actorID, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        //database connection gt issue!
        console.log(err);
        return callback(err, null);
      } else {
        const findactorByIDQuery = "SELECT * FROM actor WHERE actor_id = ?;";
        dbConn.query(findactorByIDQuery, [actorID], (error, results) => {
          dbConn.end();
          if (error) {
            return callback(error, null);
          }
          return callback(null, results);
        });
      }
    });
  },
  findAll(offset,limit,callback) {
    const dbConn = db.getConnection();
    dbConn.connect((err) => {
      if (err) {
        console.log(err);
        return callback(err, null);
      }
      const findAllactorQuery = "SELECT * FROM actor ORDER BY first_name LIMIT ?,?;";
      dbConn.query(findAllactorQuery, [limit,offset], (error, results) => {
        dbConn.end();
        if (error) {
          return callback(error, null);
        }
        return callback(null, results);
      });
      return null;
    });
  },
  create(actor, callback) {
    const dbConn = db.getConnection();
    dbConn.connect((err) => {
      if (err) {
        console.log(err);
        return callback(err, null);
      }
      const createactorQuery = "INSERT INTO actor (first_name, last_name) VALUES (?, ?);";
      dbConn.query(createactorQuery, [actor.first_name, actor.last_name], (error, results) => {
        dbConn.end();
        if (error) {
          return callback(error, null);
        }
        return callback(null, results);
      });
      return null;
    });
  },
  update(actorID, actorname, callback) {
    const dbConn = db.getConnection();
    dbConn.connect((err) => {
      if (err) {
        return callback(err, null);
      }
      const updateactorQuery = "UPDATE actor SET first_name = IFNULL(?,first_name), last_name = IFNULL(?,last_name) WHERE actor_id = ?;";
      dbConn.query(updateactorQuery, [actorname.first_name, actorname.last_name, actorID], (error, results) => {
        dbConn.end();
        if (error) {
          return callback(error, null);
        }
        return callback(null, results);
      });
      return null;
    });
  },
  delete(actorID, callback) {
    const dbConn = db.getConnection();
    dbConn.connect((err) => {
      if (err) {
        console.log(err);
        return callback(err, null);
      }
      const updateactorQuery = `
      DELETE FROM actor WHERE actor_id = ?`;
      dbConn.query(updateactorQuery, [actorID], (error, results) => {
        dbConn.end();
        if (error) {
          return callback(error, null);
        }
        return callback(null, results);
      });
      return null;
    });
  },
}
module.exports = actors;
  