//Cai Ruizhe, DAAA/1b/01 2214535

const { restart } = require("nodemon");
const db = require("./databaseconfig");
const film = {
  film_categories: function (search, category_ID, rent, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        if (category_ID == 500000) {
          const findfilmQuery = `SELECT f.title, f.description, f.rating, f.release_year, f.length, f.rental_rate, f.film_id
          FROM film f WHERE 
          f.rental_rate <= ? AND
          (f.title LIKE ? OR 
          f.description LIKE ? OR
          f.special_features LIKE ?);`;
          dbConn.query(
            findfilmQuery,
            [rent, search, search, search],
            (error, results) => {
              dbConn.end();
              if (error) {
                return callback(error, null);
              }
              return callback(null, results);
            }
          );
        } else {
          const findfilmQuery = `SELECT f.title, f.description, f.rating, f.release_year, f.length, f.rental_rate, f.film_id, c.name
          FROM film_category fc ,film f,category c WHERE f.film_id = fc.film_id AND c.category_id = fc.category_id AND
          f.rental_rate <= ? AND
          fc.category_id = ? AND
          (f.title LIKE ? OR 
          f.description LIKE ? OR
          f.special_features LIKE ?);`;
          dbConn.query(
            findfilmQuery,
            [rent, category_ID, search, search, search],
            (error, results) => {
              dbConn.end();
              if (error) {
                return callback(error, null);
              }
              return callback(null, results);
            }
          );
        }
      }
    });
  },
  findAllCategories: function (callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        const findAllcategoriesQuery = `SELECT * FROM category;`;
        dbConn.query(findAllcategoriesQuery, (error, results) => {
          dbConn.end();
          if (error) {
            return callback(error, null);
          }
          return callback(null, results);
        });
      }
    });
  },
  film_page: function (film_id, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        const film_pageQuery = `SELECT f.title, f.description, f.rating, f.length, f.rental_rate, f.release_year, f.length, c.name, fc.category_id
        FROM film f , film_category fc, category c
        WHERE c.category_id = fc.category_id AND f.film_id = fc.film_id AND
        f.film_id = ?;`;
        dbConn.query(film_pageQuery, [film_id], (error, movie) => {
          const film_pageQuery = `SELECT a.first_name, a.last_name
          FROM film f, actor a, film_actor fa
          WHERE f.film_id = fa.film_id AND fa.actor_id = a.actor_id
          AND f.film_id =  ?;`;
          dbConn.query(film_pageQuery, [film_id], (error, results) => {
            dbConn.end();
            if (error) {
              return callback(error, null);
            }
            results = { movie: movie, actors: results };
            return callback(null, results);
          });
        });
      }
    });
  },
  filmbyid: function (film_id, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        const film_pageQuery = `SELECT f.title, f.description, f.rating, f.length, f.rental_rate, f.release_year, f.length, c.name, fc.category_id
        FROM film f , film_category fc, category c
        WHERE c.category_id = fc.category_id AND f.film_id = fc.film_id AND
        f.film_id = ?;`;
        dbConn.query(film_pageQuery, [film_id], (error, movie) => {
          dbConn.end();
          if (error) {
            return callback(error, null);
          }
          return callback(null, movie);
        });
      }
    });
  },
  create: function (data, body, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        const film_verify = `SELECT * FROM film WHERE title = ?;`;
        dbConn.query(film_verify,[data.title] , (error, results) => {
          if (results.length == 0) {
            const film_pageQuery = `INSERT INTO film (title, description, release_year, language_id, rental_duration, rental_rate, length, replacement_cost, rating, special_features) 
            VALUES (?,?,?,?,?,?,?,?,?,?);`;
            dbConn.query(
              film_pageQuery,
              [
                data.title,
                data.description,
                data.release_year,
                data.language_id,
                data.rental_duration,
                data.rental_rate,
                data.length,
                data.replacement_cost,
                data.rating,
                data.special_features,
              ],
              (error, result) => {
                const film_pageQuery = `INSERT INTO film_category (film_id, category_id) VALUES (?,?);`;
                dbConn.query(
                  film_pageQuery,
                  [result.insertId, data.category_id],
                  (error, moviecat) => {
                    if (body != null) {
                      const film_pageQuery = `UPDATE film SET image = ? WHERE film_id = ?;`;
                      dbConn.query(
                        film_pageQuery,
                        [body, result.insertId],
                        (error, movieact) => {}
                      );
                    }
                    data.actor_id = data.actor_id.split(",");
                    for (let i = 0; i < data.actor_id.length; i++) {
                      const film_pageQuery = `INSERT INTO film_actor (film_id, actor_id) VALUES (?,?);`;
                      dbConn.query(
                        film_pageQuery,
                        [result.insertId, data.actor_id[i]],
                        (error, movieact) => {}
                      );
                    }
                    if (error) {
                      dbConn.end();
                      return callback(error, null);
                    } else {
                      dbConn.end();
                      return callback(null, result);
                    }
                  }
                );
              }
            );
          } else {
            dbConn.end();
            return callback("Film already exists", null);
          }
        });
      }
    });
  },
  filmimage: function (film_id, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        return callback(err, null);
      } else {
        const film_pageQuery = `SELECT image FROM film WHERE film_id = ?;`;
        dbConn.query(film_pageQuery, [film_id], (error, movie) => {
          dbConn.end();
          if (error) {
            return callback(error, null);
          }
          return callback(null, movie);
        });
      }
    });
  },
};
module.exports = film;
