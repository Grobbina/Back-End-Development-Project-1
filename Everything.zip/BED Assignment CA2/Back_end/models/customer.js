//Cai Ruizhe, DAAA/1b/01 2214535

const db = require("./databaseconfig");
const customer = {
  getCustomer: function (customer_ID, start, end, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        console.log(err);
        return callback(err, null);
      } else {
        const findUserByIDQuery =
          "select ft.title , p.amount , p.payment_date FROM film_text ft , payment p , inventory i , rental r where  r.customer_id=? and r.customer_id = p.customer_id and p.rental_id=r.rental_id and r.inventory_id=i.inventory_id and i.film_id=ft.film_id and (p.payment_date between ? and ?);";
        dbConn.query(
          findUserByIDQuery,
          [customer_ID, start, end],
          (error, results) => {
            dbConn.end();
            if (error) {
              return callback(error, null);
            }
            console.log(results);
            return callback(null, results);
          }
        );
      }
    });
  },
  create: function (customer, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        console.log(err);
        return callback(err, null);
      } else {
        const checkemailquery = "SELECT * FROM customer WHERE email = ?;";
        dbConn.query(checkemailquery, [customer.email], (error, results) => {
          if (error) {
            return callback(error, null);
          }
          if (results.length > 0) {
            return callback("Email already exists", null);
          }
          console.log('1')
          const createaddressQuery =
            "INSERT INTO address (address, address2, district, city_id, postal_code, phone) VALUES (?, ?, ?, ?, ?, ?);";
          dbConn.query(
            createaddressQuery,
            [
              customer.address,
              customer.address2,
              customer.district,
              customer.city_id,
              customer.postal_code,
              customer.phone,
            ],
            (error, results) => {
              if (error) {
                return callback(error, null);
              }
              const createCustomerQuery =
                "INSERT INTO customer (store_id, first_name, last_name, email, address_id, active) VALUES (?, ?, ?, ?, ?, ?);";
              dbConn.query(
                createCustomerQuery,
                [
                  customer.store_id,
                  customer.first_name,
                  customer.last_name,
                  customer.email,
                  results.insertId,
                  1,
                ],
                (error, results) => {
                  dbConn.end();
                  if (error) {
                    return callback(error, null);
                  }
                  return callback(null, results);
                }
              );
            }
          );
        });
      }
    });
  },
  update: function (customer_ID, staff_id, updateinfo, callback) {
    var dbConn = db.getConnection();
    dbConn.connect(function (err) {
      if (err) {
        console.log(err);
        return callback(err, null);
      } else {
        const getstoreidquery =
          "SELECT store_id FROM staff WHERE staff_id = ?;";
        dbConn.query(getstoreidquery, [staff_id], (error, store_id) => {
          if (error) {
            return callback(error, null);
          }
          const checkrightsquery =
            "SELECT * FROM customer WHERE customer_id = ?;";
          dbConn.query(checkrightsquery, [customer_ID], (error, results) => {
            if(results == [] || results == null || results == undefined || results.length == 0){
              return callback(null,results)
            }
            if (results[0].store_id != store_id[0].store_id) {
              return callback("Wrong staff member", null);
            }
            if (error) {
              return callback(error, null);
            }
            const updatecustomerquery =
              "UPDATE customer SET store_id = IFNULL(?,store_id), first_name = IFNULL(?,first_name), last_name = IFNULL(?,last_name), email = IFNULL(?,email) WHERE customer_id = ?;";
            dbConn.query(
              updatecustomerquery,
              [
                updateinfo.store_id,
                updateinfo.first_name,
                updateinfo.last_name,
                updateinfo.email,
                customer_ID,
              ],
              (error, results) => {
                if (error) {
                  return callback(error, null);
                }
                if (
                  updateinfo.address == null ||
                  updateinfo.address == undefined ||
                  updateinfo.address == ""
                ) {
                  //end connection if no address is given so no problems occur
                  dbConn.end();
                  if (error) {
                    console.log(error);
                    return callback(error, null);
                  }
                  return callback(null, results);
                }
                const updateaddressquery =
                  "UPDATE address a, customer SET a.address = IFNULL(?,a.address), a.address2 = IFNULL(?,a.address2), a.district = IFNULL(?,a.district), a.city_id = IFNULL(?,a.city_id), a.postal_code = IFNULL(?,a.postal_code), a.phone = IFNULL(?,a.phone) WHERE customer.customer_id = ? AND a.address_id = customer.address_id;";
                dbConn.query(
                  updateaddressquery,
                  [
                    updateinfo.address.address_line1,
                    updateinfo.address.address2_line2,
                    updateinfo.address.district,
                    updateinfo.address.city_id,
                    updateinfo.address.postal_code,
                    updateinfo.address.phone,
                    customer_ID,
                  ],
                  (error, results) => {
                    dbConn.end();
                    if (error) {
                      console.log(error);
                      return callback(error, null);
                    }
                    return callback(null, results);
                  }
                );
              }
            );
          });
        });
      }
    });
  },
};

module.exports = customer;
